package prog01_aorderedlist;

/**
 *
 * @author Gerald
 */
class aOrderedList {
    
}
