package prog01_aorderedlist;

/**
 *
 * @author Gerald
 */
class FileNotFoundException extends Exception {
    
}
